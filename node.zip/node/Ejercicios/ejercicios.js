
/*const showMessage=(message)=>
    {
    return message;
}
console.log (showMessage("hola"))*/
/*var a=8;
if (a%2==0){
    console.log("es un numero par");
}else{
    console.log("es un numero impar");
}*/

function busquedalineal(arr,elemento){
  for(let i=1;i<arr.length;i++){
      if(arr[i]===elemento){
          return i;
      }
  }
  return -1;
}

const arreglo=[10,2,3,8,4,9,7];
const elementobuscado=7;
const indice=busquedalineal(arreglo,elementobuscado);
console.log(`El elmento ${elementobuscado} se encuentra en el indice ${indice}`)
/*Ejercicio01*/


console.log("Ejercicio 02")
function mayorMenor(arr) {
  let mayor = arr[0];
  let menor = arr[0];
  for (let i = 1; i < arr.length; i++) {
    if (arr[i] > mayor) mayor = arr[i];
    if (arr[i] < menor) menor = arr[i];
  }
  return { mayor, menor };
}
console.log(mayorMenor([3, 1, 4, 1, 5]));

console.log("Ejercicio 03")
function contarPares(arr) {
  let contador = 0;
  for (let i = 0; i < arr.length; i++) {
    if (arr[i] % 2 === 0) contador++;
  }
  return contador;
}
console.log(contarPares([1, 2, 3, 4, 6]));

console.log("Ejercicio 04")
function ordenarArray(arr) {
  let n = arr.length;
  for (let i = 0; i < n - 1; i++) {
    for (let j = 0; j < n - i - 1; j++) {
      if (arr[j] > arr[j + 1]) {
        let temp = arr[j];
        arr[j] = arr[j + 1];
        arr[j + 1] = temp;
      }
    }
  }
  return arr;
}
console.log(ordenarArray([5, 2, 9, 1, 5]));

console.log("Ejercicio 05")
function buscarNombre(arr, nombre) {
  for (let i = 0; i < arr.length; i++) {
    if (arr[i] === nombre) return i;
  }
  return -1;
}
console.log(buscarNombre(["Ana", "Juan", "María"], "Juan"));
console.log(buscarNombre(["Ana", "Juan", "María"], "Pedro")); 


console.log("Ejercicio 06")
function revertirArray(arr) {
  let nuevoArr = [];
  for (let i = arr.length - 1; i >= 0; i--) {
    nuevoArr.push(arr[i]);
  }
  return nuevoArr;
}
console.log(revertirArray([1, 2, 3, 4]));

console.log("Ejercicio 07")
function nombresMayusculas(arr) {
  return arr.map(nombre => nombre.toUpperCase());
}
console.log(nombresMayusculas(["ana", "juan", "maría"]));

console.log("Ejercicio 08")
function sumarPositivos(arr) {
  return arr.filter(num => num > 0).reduce((suma, num) => suma + num, 0);
}
console.log(sumarPositivos([1, -2, 3, -4, 5])); 

console.log("ejercico 09")
function multiploCinco(arr) {
  return arr.find(num => num % 5 === 0);
}
console.log(multiploCinco([2, 3, 7, 10, 12]));

// Verifica que solo tengas esta línea una vez en tu archivo
const inputOutput = require("readline");

const interfaceUsuario = inputOutput.createInterface({
input: process.stdin,
output: process.stdout
});

// Función auxiliar para hacer preguntas
function preguntar(pregunta) {
return new Promise(resolve => interfaceUsuario.question(pregunta, resolve));
}

// Ejercicio 10: Tabla de multiplicar
async function mostrarTablaMultiplicar() {
console.log("Ejercicio 10");
let valor = await preguntar("Ingresa un número para ver su tabla de multiplicar: ");
let numeroIngresado = parseInt(valor);

if (!isNaN(numeroIngresado)) {
  for (let i = 1; i <= 10; i++) {
    console.log(`${numeroIngresado} x ${i} = ${numeroIngresado * i}`);
  }
} else {
  console.log("Por favor, ingresa un número válido.");
}
}

// Ejercicio 11: Secuencia de Fibonacci
function fibonacci() {
console.log("Ejercicio 11");
let secuencia = [0, 1];
for (let i = 2; i < 10; i++) {
  secuencia.push(secuencia[i - 1] + secuencia[i - 2]);
}
return secuencia;
}

// Función principal para ejecutar los ejercicios en orden
async function main() {
await mostrarTablaMultiplicar();
console.log(fibonacci());
interfaceUsuario.close(); // Cerramos la interfaz al final
}

main();

// Importamos readline para entrada de datos
const readline = require('readline');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

console.log("Ejercicio 12");
function adivinarValor() {
  return new Promise((resolver) => {
    let numeroAleatorio = Math.floor(Math.random() * 10) + 1;
    let intentoJugador;

    function hacerPregunta() {
      rl.question("Adivina el número (1-10): ", (respuestaJugador) => {
        intentoJugador = parseInt(respuestaJugador);

        if (isNaN(intentoJugador) || intentoJugador < 1 || intentoJugador > 10) {
          console.log("Por favor, ingresa un número válido entre 1 y 10.");
          hacerPregunta();
        } else if (intentoJugador < numeroAleatorio) {
          console.log("Más alto");
          hacerPregunta();
        } else if (intentoJugador > numeroAleatorio) {
          console.log("Más bajo");
          hacerPregunta();
        } else {
          console.log("¡Correcto!");
          resolver();
        }
      });
    }

    hacerPregunta();
  });
}

console.log("Ejercicio 14");
function ejercicio14() {
  return new Promise((res) => {
    rl.question("Ingresa un número mayor que 0: ", (input) => {
      let numero = parseInt(input);

      if (numero > 0 && !isNaN(numero)) {
        console.log(`Número válido ingresado: ${numero}`);
      } else {
        console.log("Número no válido. Ingresa un número mayor que 0.");
      }

      res();
    });
  });
}

console.log("Ejercicio 15");
function mostrarMenu() {
  return new Promise((res) => {
    function mostrar() {
      rl.question("Menú:\n1. Opción 1\n2. Opción 2\n3. Salir\nElige una opción: ", (opcion) => {
        switch (opcion) {
          case "1": console.log("Elegiste Opción 1"); break;
          case "2": console.log("Elegiste Opción 2"); break;
          case "3": console.log("Saliendo..."); return res();
          default: console.log("Opción inválida");
        }
        mostrar();
      });
    }
    mostrar();
  });
}

console.log("Ejercicio 16");
function sumarImpares() {
  let suma = 0;
  for (let i = 1; i <= 50; i++) {
    if (i % 2 !== 0) {
      suma += i;
      if (suma > 500) {
        console.log(`Suma superó 500: ${suma}`);
        break;
      }
    }
  }
  console.log("Suma final de impares:", suma);
}

console.log("Ejercicio 17");
function contadorIntentos() {
  return new Promise((res) => {
    let intentos = 3;
    function pedir() {
      rl.question("Ingresa la contraseña: ", (login) => {
        if (login === "1234") {
          console.log("¡Login exitoso!");
          return res();
        }
        intentos--;
        console.log(`Intentos restantes: ${intentos}`);
        if (intentos === 0) {
          console.log("Acceso bloqueado");
          return res();
        }
        pedir();
      });
    }
    pedir();
  });
}

console.log("Ejercicio 18");
function sumarHastaCero() {
  return new Promise((res) => {
    let suma = 0;
    function pedirNumero() {
      rl.question("Ingresa un número (0 para terminar): ", (input) => {
        let numero = parseInt(input);
        if (!isNaN(numero)) {
          suma += numero;
          if (numero !== 0) {
            pedirNumero();
          } else {
            console.log("Suma total:", suma);
            res();
          }
        } else {
          console.log("Número inválido");
          pedirNumero();
        }
      });
    }
    pedirNumero();
  });
}

console.log("Ejercicio 19");
function fibonacciHasta100() {
  let secuencia = [0, 1];
  let siguiente;
  while ((siguiente = secuencia[secuencia.length - 1] + secuencia[secuencia.length - 2]) <= 100) {
    secuencia.push(siguiente);
  }
  console.log("Fibonacci hasta 100:", secuencia);
}

console.log("Ejercicio 20");
function multiplosTres() {
  let i = 3;
  while (i < 50) {
    console.log(i);
    i += 3;
  }
}

// Ejecutamos todos los ejercicios secuencialmente (los que requieren input)
async function ejecutarTodo() {
  await adivinarValor();
  await ejercicio14();
  await mostrarMenu();
  sumarImpares();
  await contadorIntentos();
  await sumarHastaCero();
  fibonacciHasta100();
  multiplosTres();
  rl.close();
}

ejecutarTodo();
