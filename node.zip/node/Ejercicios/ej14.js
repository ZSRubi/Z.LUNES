console.log("Ejercicio 14");
const readline = require('readline');

// Crear la interfaz para leer entradas
const rl1= readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

rl1.question("Ingresa un número mayor que 0: ", (input) => {
  let numero = parseInt(input);

  if (numero > 0 && !isNaN(numero)) {
    console.log(`Número válido ingresado: ${numero}`);
  } else {
    console.log("Número no válido. Ingresa un número mayor que 0.");
  }

  rl.close();  // Cierra la interfaz al final
});