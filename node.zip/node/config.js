module.exports={
    db:{
        host:'localhost',
        user:'',
        password:'',
        database:'mydb',
        port: 27017
    }
}